import os
import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, CommandHandler, ContextTypes, filters
from PIL import Image
from datetime import datetime

def enhance_image(image_path, model='realesrgan'):
    output_path = f"output/clear_{datetime.now().timestamp()}.png"

    if model == 'realesrgan':
        from ai_models.realesrgan.infer import run_realesrgan
        return run_realesrgan(image_path, output_path)

    elif model == 'gfpgan':
        from ai_models.gfpgan.infer import run_gfpgan
        return run_gfpgan(image_path, output_path)

    elif model == 'codeformer':
        from ai_models.codeformer.infer import run_codeformer
        return run_codeformer(image_path, output_path)

    else:
        raise ValueError("Unsupported model.")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋 សួស្តី! សូមផ្ញើររូប Blur មកខ្ញុំ។ ខ្ញុំនឹងបំលែងវាជារូបច្បាស់ដោយ AI។")

async def handle_image(update: Update, context: ContextTypes.DEFAULT_TYPE):
    photo = update.message.photo[-1]
    file = await context.bot.get_file(photo.file_id)
    file_path = f"input/{photo.file_id}.jpg"
    await file.download_to_drive(file_path)

    await update.message.reply_text("🧠 กำลัง處理រូបភាព... សូមរងចាំ")

    output_path = enhance_image(file_path, model='realesrgan')
    await update.message.reply_photo(photo=open(output_path, 'rb'), caption="✅ រូបភាពដែលបានបំលែងដោយ AI")

logging.basicConfig(level=logging.INFO)
TOKEN = "7643490329:AAFDxe-SopZ_sBUXNLCEf-xrH-pXxtkIP4U"
app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.PHOTO, handle_image))

if __name__ == "__main__":
    os.makedirs("input", exist_ok=True)
    os.makedirs("output", exist_ok=True)
    print("🤖 Bot is running...")
    app.run_polling()
