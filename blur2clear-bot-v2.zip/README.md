# Blur2Clear Bot
Run the bot using:

python main.py