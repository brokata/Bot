from PIL import Image, ImageEnhance
def run_realesrgan(input_path, output_path):
    img = Image.open(input_path).convert('RGB')
    enhancer = ImageEnhance.Sharpness(img)
    enhanced_img = enhancer.enhance(2.5)
    enhanced_img.save(output_path)
    return output_path
