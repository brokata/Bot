from PIL import Image, ImageEnhance
def run_gfpgan(input_path, output_path):
    img = Image.open(input_path).convert('RGB')
    enhancer = ImageEnhance.Contrast(img)
    enhanced_img = enhancer.enhance(1.8)
    enhanced_img.save(output_path)
    return output_path
